"""Subway_Passenger_Flow URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin

from Analysis_Admin import views as adminview
from Analysis_User  import views as userview


urlpatterns = [
    url('admin/', admin.site.urls),

    url(r'^$', userview.login, name='login'),
    url(r'^viewsubwaydata/$',userview.viewsubwaydata,name='viewsubwaydata'),
    url('viewtreandingtopics/(?P<chart_type>\w+)/$',userview.viewtreandingtopics,name="viewtreandingtopics"),
    url('negaviewfeedbacktivechart/(?P<chart_type>\w+)/$',userview.negativechart,name="negativechart"),
    url('nutralchart/(?P<chart_type>\w+)/$',userview.nutralchart,name="nutralchart"),
    url(r'^charts/(?P<chart_type>\w+)', userview.charts, name="charts"),

    url(r'^admin_login/$',adminview.admin_login, name='admin_login'),
    url(r'^userdetails/$',adminview.userdetails, name='userdetails'),
    url(r'^uploaddata/$',adminview.uploaddata, name='uploaddata'),

]
