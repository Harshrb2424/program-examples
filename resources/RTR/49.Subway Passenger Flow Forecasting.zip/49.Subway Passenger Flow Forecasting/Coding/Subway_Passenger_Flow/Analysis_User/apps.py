from django.apps import AppConfig


class AnalysisUserConfig(AppConfig):
    name = 'Analysis_User'
