from django.db.models import Count
from django.shortcuts import render, redirect


# Create your views here.
from Analysis_Admin.models import UploadData
from Analysis_User.models import UserRegister_Model


def login(request):
    if request.method == "POST" and 'submit' in request.POST:

        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phoneno = request.POST.get('phoneno')
        gender = request.POST.get('gender')
        country = request.POST.get('country')
        state = request.POST.get('state')
        city = request.POST.get('city')
        UserRegister_Model.objects.create(username=username, email=email, password=password,gender=gender, phoneno=phoneno,
                                                country=country, state=state, city=city)



    if request.method == "POST" and 'submit1' in request.POST:

        username = request.POST.get('username')
        password = request.POST.get('password')
        try:

            enter = UserRegister_Model.objects.get(username=username, password=password)
            request.session["userid"] = enter.id
            return redirect('viewsubwaydata')
        except:
            pass
    return render(request,'user/login.html')

def viewsubwaydata(request):
    obj = UploadData.objects.all()
    return render(request,'user/viewsubwaydata.html',{'obj':obj})
def viewtreandingtopics(request,chart_type):
    dd = {}
    pos,neu,neg =0,0,0
    poss=None
    topic = UploadData.objects.values('line').annotate(dcount=Count('line')).order_by('-dcount')
    for t in topic:
        line=t['line']
        pos_count=UploadData.objects.filter(line=line).values('sentiment').annotate(topiccount=Count('line'))
        poss=pos_count
        for pp in pos_count:
            senti= pp['sentiment']
            if senti == 'commercial_area':
                pos= pp['topiccount']
            elif senti == 'residential_area':
                neg = pp['topiccount']
            elif senti == 'nutral':
                neu = pp['topiccount']
        dd[line]=[pos,neg,neu]
    return render(request,'user/viewtreandingtopics.html',{'object':topic,'dd':dd,'chart_type':chart_type})

def negativechart(request,chart_type):
    dd = {}
    pos, neu, neg = 0, 0, 0
    poss = None
    topic = UploadData.objects.values('line').annotate(dcount=Count('line')).order_by('-dcount')
    for t in topic:
        line = t['line']
        pos_count = UploadData.objects.filter(line=line).values('sentiment').annotate(topiccount=Count('line'))
        poss = pos_count
        for pp in pos_count:
            senti = pp['sentiment']
            if senti == 'commercial_area':
                pos = pp['topiccount']
            elif senti == 'residential_area':
                neg = pp['topiccount']
            elif senti == 'nutral':
                neu = pp['topiccount']
        dd[line] = [pos, neg, neu]
    return render(request,'user/negativechart.html',{'object':topic,'dd':dd,'chart_type':chart_type})

def nutralchart(request,chart_type):
    dd = {}
    pos, neu, neg = 0, 0, 0
    poss = None
    topic = UploadData.objects.values('line').annotate(dcount=Count('line')).order_by('-dcount')
    for t in topic:
        line = t['line']
        pos_count = UploadData.objects.filter(line=line).values('sentiment').annotate(topiccount=Count('line'))
        poss = pos_count
        for pp in pos_count:
            senti = pp['sentiment']
            if senti == 'commercial_area':
                pos = pp['topiccount']
            elif senti == 'residential_area':
                neg = pp['topiccount']
            elif senti == 'nutral':
                neu = pp['topiccount']
        dd[line] = [pos, neg, neu]
    return render(request,'user/nutralchart.html',{'object':topic,'dd':dd,'chart_type':chart_type})
def charts(request,chart_type):
    chart = UploadData.objects.values('sentiment').annotate(dcount=Count('line'))

    return render(request,"user/charts.html", {'form':chart, 'chart_type':chart_type})



