from django.shortcuts import render, redirect


# Create your views here.
from Analysis_Admin.models import UploadData
from Analysis_User.models import UserRegister_Model


def admin_login(request):
    if request.method  == "POST":
        admin = request.POST.get('admin')
        password = request.POST.get('password')
        if admin == "admin" and password =="admin":
            return redirect('userdetails')


    return render(request,'admin/admin_login.html')


def base(request):
    return render(request,'admin/admin_login.html')

def userdetails(request):
    obj =UserRegister_Model.objects.all()

    return render(request,'admin/userdetails.html',{'object':obj})

def uploaddata(request):
    calculate = 0
    calculate1 = 0
    pos = []
    neg = []
    oth = []
    se = 'se'
    if request.method == "POST":
        division = request.POST.get('division')
        line = request.POST.get('line')
        stationname = request.POST.get('stationname')
        slatitude = request.POST.get('slatitude')
        slongitude = request.POST.get('slongitude')
        r1 = request.POST.get('r1')
        r2 = request.POST.get('r2')
        r3 = request.POST.get('r3')
        r4 = request.POST.get('r4')
        r5 = request.POST.get('r5')
        r6 = request.POST.get('r6')
        entrancetype = request.POST.get('entrancetype')
        entry = request.POST.get('entry')
        vending = request.POST.get('vending')
        staffing = request.POST.get('staffing')
        nss = request.POST.get('nss')
        ews = request.POST.get('ews')
        entrance = request.POST.get('entrance')
        entranceexit = request.POST.get('entranceexit')
        time = request.POST.get('time')


        calculate = (int(entrance) - int(entranceexit))



        if calculate >= 300000 and calculate <= 1000000:
            pos.append(calculate)
        elif calculate > 1000000 and calculate <=2000000 :
            neg.append(calculate)
        else:
            oth.append(calculate)
        if len(pos) > len(neg):
            se = 'positive'
        elif len(neg) > len(pos):
            se = 'negative'
        else:
            se = 'nutral'


        UploadData.objects.create(division=division, line=line, stationname=stationname, slatitude=slatitude,
                                          slongitude=slongitude,r1=r1, r2=r2, r3=r3,r4=r4,r5=r5,r6=r6,entrancetype=entrancetype,entry=entry,vending=vending,
                                          staffing=staffing,nss=nss,ews=ews,entrance=entrance, entranceexit=entranceexit,time=time,calculate=calculate,sentiment=se )

    return render(request,'admin/uploaddata.html')