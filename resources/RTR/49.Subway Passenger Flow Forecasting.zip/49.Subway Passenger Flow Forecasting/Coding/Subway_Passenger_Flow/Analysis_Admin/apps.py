from django.apps import AppConfig


class AnalysisAdminConfig(AppConfig):
    name = 'Analysis_Admin'
