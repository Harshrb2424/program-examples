from django.db import models

# Create your models here.
class UploadData(models.Model):
    division = models.CharField(max_length=50)
    line = models.CharField(max_length=50)
    stationname = models.CharField(max_length=50)
    slatitude = models.CharField(max_length=50)
    slongitude = models.CharField(max_length=50)
    r1 = models.CharField(max_length=30)
    r2 = models.CharField(max_length=30)
    r3 = models.CharField(max_length=30)
    r4 = models.CharField(max_length=30)
    r5 = models.CharField(max_length=30)
    r6 = models.CharField(max_length=30)
    entrancetype = models.CharField(max_length=30)
    entry = models.CharField(max_length=30)
    vending = models.CharField(max_length=30)
    staffing = models.CharField(max_length=30)
    nss = models.CharField(max_length=30)
    ews = models.CharField(max_length=30)
    entrance = models.IntegerField()
    entranceexit = models.IntegerField()
    time = models.TimeField(max_length=30)
    calculate =models.IntegerField()
    sentiment = models.CharField(max_length=300)

def calculate(self):

    return self.entrance - self.entranceexit
